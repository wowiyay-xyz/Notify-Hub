import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { ThemeToggle } from "./ThemeToggle";
import { Toaster } from "sonner";
import { NotificationDashboard } from "./NotificationDashboard";

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-slate-900 dark:via-blue-900 dark:to-indigo-900 relative overflow-hidden transition-all duration-500">
      {/* Enhanced Animated Background Elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        {/* Primary floating orbs */}
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-gradient-to-br from-blue-400/30 to-purple-500/30 dark:from-blue-600/20 dark:to-purple-700/20 rounded-full blur-3xl animate-float"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-gradient-to-br from-indigo-400/30 to-pink-500/30 dark:from-indigo-600/20 dark:to-pink-700/20 rounded-full blur-3xl animate-float-reverse"></div>
        
        {/* Secondary floating elements */}
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-gradient-to-br from-cyan-400/20 to-blue-500/20 dark:from-cyan-600/15 dark:to-blue-700/15 rounded-full blur-2xl animate-pulse-glow"></div>
        <div className="absolute bottom-1/4 right-1/4 w-48 h-48 bg-gradient-to-br from-purple-400/25 to-pink-500/25 dark:from-purple-600/15 dark:to-pink-700/15 rounded-full blur-2xl animate-morphing"></div>
        
        {/* Geometric shapes */}
        <div className="absolute top-1/3 right-1/3 w-32 h-32 bg-gradient-to-br from-emerald-400/20 to-teal-500/20 dark:from-emerald-600/15 dark:to-teal-700/15 rotate-45 blur-xl animate-float"></div>
        <div className="absolute bottom-1/3 left-1/3 w-24 h-24 bg-gradient-to-br from-orange-400/20 to-red-500/20 dark:from-orange-600/15 dark:to-red-700/15 rounded-full blur-lg animate-bounce-in"></div>
        
        {/* Subtle grid pattern */}
        <div className="absolute inset-0 opacity-40 dark:opacity-20" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%239C92AC' fill-opacity='0.05'%3E%3Ccircle cx='30' cy='30' r='1'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
      </div>

      <header className="sticky top-0 z-50 glass-strong border-b border-white/30 dark:border-white/10 shadow-modern">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex items-center space-x-4 animate-slide-in-left">
              <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-modern animate-pulse-glow">
                <span className="text-white text-2xl font-bold">📧</span>
              </div>
              <div>
                <h2 className="text-2xl font-bold font-accent gradient-text-primary">
                  NotifyHub
                </h2>
                <p className="text-sm text-gray-600 dark:text-gray-400 font-medium">Beautiful Email Notifications</p>
              </div>
            </div>
            <div className="flex items-center space-x-4 animate-slide-in-right">
              <ThemeToggle />
              <SignOutButton />
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 flex-1 p-4 sm:p-6 lg:p-8">
        <Content />
      </main>

      {/* Enhanced Footer */}
      <footer className="relative z-10 glass-strong border-t border-white/30 dark:border-white/10 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center animate-pulse-glow">
                <span className="text-white text-sm">✨</span>
              </div>
              <p className="text-lg font-semibold font-secondary gradient-text-primary">
                Crafted with passion
              </p>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400 font-medium">
              Created by{" "}
              <span className="font-bold gradient-text-secondary">
                wowiyay
              </span>
              {" "}& powered by{" "}
              <span className="font-bold gradient-text-tertiary">
                Chef Convex
              </span>
              {" "}🚀
            </p>
          </div>
        </div>
      </footer>
      
      <Toaster 
        position="top-right"
        toastOptions={{
          style: {
            background: 'rgba(255, 255, 255, 0.95)',
            backdropFilter: 'blur(20px)',
            border: '1px solid rgba(255, 255, 255, 0.3)',
            boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.15)',
            borderRadius: '16px',
            fontFamily: 'Inter, sans-serif',
            fontWeight: '500',
          }
        }}
      />
    </div>
  );
}

function Content() {
  const loggedInUser = useQuery(api.auth.loggedInUser);

  if (loggedInUser === undefined) {
    return (
      <div className="flex justify-center items-center min-h-96">
        <div className="relative">
          <div className="spinner-modern"></div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-6 h-6 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full animate-pulse"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto">
      <Authenticated>
        <div className="mb-12 text-center animate-slide-in-up">
          <div className="inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-600 rounded-3xl shadow-modern mb-8 animate-bounce-in">
            <span className="text-4xl animate-float">👋</span>
          </div>
          <h1 className="text-5xl sm:text-6xl font-bold font-accent gradient-text-primary mb-6 text-shadow-lg">
            Welcome back, {loggedInUser?.email?.split('@')[0] ?? "friend"}!
          </h1>
          <p className="text-xl text-gray-700 dark:text-gray-300 max-w-3xl mx-auto font-medium leading-relaxed">
            Send beautiful email notifications with advanced scheduling and real-time tracking
          </p>
          <div className="mt-8 flex justify-center">
            <div className="flex items-center space-x-2 glass px-6 py-3 rounded-full">
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-sm font-semibold text-gray-700 dark:text-gray-300">System Online</span>
            </div>
          </div>
        </div>
        <div className="animate-slide-in-up" style={{ animationDelay: '0.2s' }}>
          <NotificationDashboard />
        </div>
      </Authenticated>

      <Unauthenticated>
        <div className="max-w-lg mx-auto animate-slide-in-up">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-32 h-32 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full shadow-modern mb-10 animate-bounce-in">
              <span className="text-5xl animate-float">📧</span>
            </div>
            <h1 className="text-5xl sm:text-6xl font-bold font-accent gradient-text-primary mb-6 text-shadow-lg">
              NotifyHub
            </h1>
            <p className="text-xl text-gray-700 dark:text-gray-300 font-medium leading-relaxed">
              Sign in to start sending beautiful email notifications
            </p>
          </div>
          <div className="card-modern rounded-3xl p-10">
            <SignInForm />
          </div>
        </div>
      </Unauthenticated>
    </div>
  );
}

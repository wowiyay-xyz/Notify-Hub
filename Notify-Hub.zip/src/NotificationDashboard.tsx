import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { toast } from "sonner";
import { Id } from "../convex/_generated/dataModel";

export function NotificationDashboard() {
  const [activeTab, setActiveTab] = useState<"send" | "history" | "stats">("send");
  
  return (
    <div className="space-y-10">
      {/* Enhanced Tab Navigation */}
      <div className="card-modern rounded-3xl p-3 shadow-modern">
        <nav className="flex space-x-3">
          {[
            { id: "send", label: "Send Notification", icon: "📤", gradient: "btn-gradient-primary" },
            { id: "history", label: "History", icon: "📋", gradient: "btn-gradient-secondary" },
            { id: "stats", label: "Statistics", icon: "📊", gradient: "btn-gradient-quaternary" },
          ].map((tab, index) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex-1 py-4 px-8 rounded-2xl font-bold text-lg transition-all duration-300 transform hover:scale-105 tab-modern ${
                activeTab === tab.id
                  ? `${tab.gradient} text-white shadow-modern active`
                  : "text-gray-600 hover:text-gray-800 hover:bg-gray-50/50 glass"
              }`}
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <span className="text-2xl mr-3">{tab.icon}</span>
              <span className="font-accent">{tab.label}</span>
            </button>
          ))}
        </nav>
      </div>

      {/* Enhanced Tab Content */}
      <div className="transition-all duration-500 ease-in-out">
        {activeTab === "send" && <SendNotificationForm />}
        {activeTab === "history" && <NotificationHistory />}
        {activeTab === "stats" && <NotificationStats />}
      </div>
    </div>
  );
}

function SendNotificationForm() {
  const [title, setTitle] = useState("");
  const [message, setMessage] = useState("");
  const [recipientEmail, setRecipientEmail] = useState("");
  const [priority, setPriority] = useState<"low" | "normal" | "high" | "urgent">("normal");
  const [scheduleDate, setScheduleDate] = useState("");
  const [scheduleTime, setScheduleTime] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const createNotification = useMutation(api.notifications.createNotification);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !message.trim() || !recipientEmail.trim()) {
      toast.error("Please fill in all required fields");
      return;
    }

    setIsSubmitting(true);
    try {
      let scheduledFor: number | undefined;
      
      if (scheduleDate && scheduleTime) {
        const scheduledDateTime = new Date(`${scheduleDate}T${scheduleTime}`);
        if (scheduledDateTime > new Date()) {
          scheduledFor = scheduledDateTime.getTime();
        }
      }

      await createNotification({
        title: title.trim(),
        message: message.trim(),
        recipientEmail: recipientEmail.trim(),
        priority,
        scheduledFor,
      });

      toast.success(scheduledFor ? "Notification scheduled successfully! 🎉" : "Notification sent successfully! 🚀");
      
      // Reset form
      setTitle("");
      setMessage("");
      setRecipientEmail("");
      setPriority("normal");
      setScheduleDate("");
      setScheduleTime("");
    } catch (error) {
      toast.error("Failed to send notification");
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const priorityOptions = [
    { value: "low", label: "Low Priority", icon: "📝", gradient: "from-gray-400 to-gray-500" },
    { value: "normal", label: "Normal Priority", icon: "📧", gradient: "from-blue-400 to-blue-500" },
    { value: "high", label: "High Priority", icon: "⚡", gradient: "from-orange-400 to-orange-500" },
    { value: "urgent", label: "Urgent", icon: "🚨", gradient: "from-red-400 to-red-500" },
  ];

  return (
    <div className="card-modern rounded-3xl shadow-modern overflow-hidden animate-slide-in-up">
      <div className="bg-gradient-to-r from-blue-500 via-purple-600 to-pink-500 p-8 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="relative z-10">
          <h2 className="text-4xl font-bold text-white flex items-center font-accent">
            <span className="mr-4 text-5xl animate-float">✨</span>
            Send New Notification
          </h2>
          <p className="text-blue-100 mt-3 text-lg font-medium">Create and send beautiful email notifications</p>
        </div>
      </div>
      
      <form onSubmit={handleSubmit} className="p-10 space-y-8">
        <div className="group animate-slide-in-left" style={{ animationDelay: '0.1s' }}>
          <label htmlFor="title" className="block text-lg font-bold text-gray-800 mb-3 group-focus-within:text-blue-600 transition-colors font-secondary">
            Title *
          </label>
          <input
            type="text"
            id="title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="input-modern text-lg"
            placeholder="Enter a compelling title..."
            required
          />
        </div>

        <div className="group animate-slide-in-right" style={{ animationDelay: '0.2s' }}>
          <label htmlFor="message" className="block text-lg font-bold text-gray-800 mb-3 group-focus-within:text-blue-600 transition-colors font-secondary">
            Message *
          </label>
          <textarea
            id="message"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={6}
            className="input-modern text-lg resize-none"
            placeholder="Write your message here..."
            required
          />
        </div>

        <div className="group animate-slide-in-left" style={{ animationDelay: '0.3s' }}>
          <label htmlFor="email" className="block text-lg font-bold text-gray-800 mb-3 group-focus-within:text-blue-600 transition-colors font-secondary">
            Recipient Email *
          </label>
          <input
            type="email"
            id="email"
            value={recipientEmail}
            onChange={(e) => setRecipientEmail(e.target.value)}
            className="input-modern text-lg"
            placeholder="recipient@example.com"
            required
          />
        </div>

        <div className="animate-slide-in-up" style={{ animationDelay: '0.4s' }}>
          <label className="block text-lg font-bold text-gray-800 mb-4 font-secondary">
            Priority Level
          </label>
          <div className="grid grid-cols-2 gap-4">
            {priorityOptions.map((option, index) => (
              <button
                key={option.value}
                type="button"
                onClick={() => setPriority(option.value as any)}
                className={`p-6 rounded-2xl border-2 transition-all duration-300 transform hover:scale-105 ${
                  priority === option.value
                    ? `bg-gradient-to-r ${option.gradient} text-white border-transparent shadow-modern`
                    : "border-gray-200 glass hover:border-gray-300"
                }`}
                style={{ animationDelay: `${0.5 + index * 0.1}s` }}
              >
                <div className="flex items-center justify-center space-x-3">
                  <span className="text-3xl">{option.icon}</span>
                  <span className="font-bold text-lg font-secondary">{option.label}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="glass-strong rounded-2xl p-8 border border-purple-200/50 animate-slide-in-right" style={{ animationDelay: '0.6s' }}>
          <h3 className="text-2xl font-bold text-gray-800 mb-6 flex items-center font-accent">
            <span className="mr-3 text-3xl">⏰</span>
            Schedule for Later (Optional)
          </h3>
          <div className="grid grid-cols-2 gap-6">
            <div>
              <label htmlFor="scheduleDate" className="block text-lg font-semibold text-gray-700 mb-3 font-secondary">
                Date
              </label>
              <input
                type="date"
                id="scheduleDate"
                value={scheduleDate}
                onChange={(e) => setScheduleDate(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
                className="input-modern"
              />
            </div>
            <div>
              <label htmlFor="scheduleTime" className="block text-lg font-semibold text-gray-700 mb-3 font-secondary">
                Time
              </label>
              <input
                type="time"
                id="scheduleTime"
                value={scheduleTime}
                onChange={(e) => setScheduleTime(e.target.value)}
                className="input-modern"
              />
            </div>
          </div>
        </div>

        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full btn-modern text-white py-6 px-8 rounded-2xl font-bold text-xl shadow-modern hover:shadow-modern-hover disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none animate-slide-in-up"
          style={{ animationDelay: '0.7s' }}
        >
          {isSubmitting ? (
            <div className="flex items-center justify-center space-x-3">
              <div className="w-6 h-6 border-3 border-white border-t-transparent rounded-full animate-spin"></div>
              <span className="font-accent">Sending...</span>
            </div>
          ) : (
            <div className="flex items-center justify-center space-x-3">
              <span className="text-2xl">{scheduleDate && scheduleTime ? "⏰" : "🚀"}</span>
              <span className="font-accent">{scheduleDate && scheduleTime ? "Schedule Notification" : "Send Notification"}</span>
            </div>
          )}
        </button>
      </form>
    </div>
  );
}

function NotificationHistory() {
  const notifications = useQuery(api.notifications.getUserNotifications, { limit: 100 });
  const cancelNotification = useMutation(api.notifications.cancelNotification);

  const handleCancel = async (notificationId: Id<"notifications">) => {
    try {
      await cancelNotification({ notificationId });
      toast.success("Notification cancelled successfully! ✅");
    } catch (error) {
      toast.error("Failed to cancel notification");
    }
  };

  const getStatusConfig = (status: string) => {
    switch (status) {
      case "pending": return { bg: "bg-gradient-to-r from-yellow-400 to-orange-400", text: "text-white", icon: "⏳" };
      case "sent": return { bg: "bg-gradient-to-r from-blue-400 to-cyan-400", text: "text-white", icon: "📤" };
      case "delivered": return { bg: "bg-gradient-to-r from-green-400 to-emerald-400", text: "text-white", icon: "✅" };
      case "bounced": return { bg: "bg-gradient-to-r from-red-400 to-pink-400", text: "text-white", icon: "❌" };
      case "complained": return { bg: "bg-gradient-to-r from-purple-400 to-indigo-400", text: "text-white", icon: "⚠️" };
      case "cancelled": return { bg: "bg-gradient-to-r from-gray-400 to-gray-500", text: "text-white", icon: "🚫" };
      default: return { bg: "bg-gray-100", text: "text-gray-800", icon: "❓" };
    }
  };

  const getPriorityConfig = (priority: string) => {
    switch (priority) {
      case "low": return { emoji: "📝", color: "text-gray-600" };
      case "normal": return { emoji: "📧", color: "text-blue-600" };
      case "high": return { emoji: "⚡", color: "text-orange-600" };
      case "urgent": return { emoji: "🚨", color: "text-red-600" };
      default: return { emoji: "📧", color: "text-blue-600" };
    }
  };

  if (notifications === undefined) {
    return (
      <div className="card-modern rounded-3xl shadow-modern p-10">
        <div className="animate-pulse space-y-8">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="bg-gradient-to-r from-gray-200 to-gray-300 h-32 rounded-2xl animate-shimmer"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="card-modern rounded-3xl shadow-modern overflow-hidden animate-slide-in-up">
      <div className="bg-gradient-to-r from-purple-500 via-pink-600 to-red-500 p-8 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="relative z-10">
          <h2 className="text-4xl font-bold text-white flex items-center font-accent">
            <span className="mr-4 text-5xl animate-float">📋</span>
            Notification History
          </h2>
          <p className="text-purple-100 mt-3 text-lg font-medium">Track all your sent notifications</p>
        </div>
      </div>
      
      {notifications.length === 0 ? (
        <div className="p-16 text-center">
          <div className="w-32 h-32 bg-gradient-to-br from-gray-200 to-gray-300 rounded-full flex items-center justify-center mx-auto mb-8 animate-bounce-in">
            <span className="text-5xl">📭</span>
          </div>
          <h3 className="text-2xl font-bold text-gray-700 mb-4 font-accent">No notifications yet</h3>
          <p className="text-gray-500 text-lg font-medium">Send your first notification to see it here!</p>
        </div>
      ) : (
        <div className="divide-y divide-gray-100/50">
          {notifications.map((notification, index) => {
            const statusConfig = getStatusConfig(notification.status);
            const priorityConfig = getPriorityConfig(notification.priority);
            
            return (
              <div 
                key={notification._id} 
                className="notification-card animate-slide-in-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-4 mb-4">
                      <span className={`text-3xl ${priorityConfig.color}`}>{priorityConfig.emoji}</span>
                      <h3 className="text-2xl font-bold text-gray-900 font-accent">{notification.title}</h3>
                      <div className={`px-4 py-2 rounded-full text-sm font-bold ${statusConfig.bg} ${statusConfig.text} flex items-center space-x-2 shadow-lg`}>
                        <span className="text-lg">{statusConfig.icon}</span>
                        <span className="capitalize font-secondary">{notification.status}</span>
                      </div>
                    </div>
                    
                    <div className="glass rounded-2xl p-6 mb-6">
                      <p className="text-gray-700 leading-relaxed text-lg font-medium">{notification.message}</p>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-base">
                      <div className="flex items-center space-x-3">
                        <span className="text-blue-500 text-xl">📧</span>
                        <span className="text-gray-600 font-semibold">To:</span>
                        <span className="font-bold text-gray-800">{notification.recipientEmail}</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <span className="text-green-500 text-xl">📅</span>
                        <span className="text-gray-600 font-semibold">Sent:</span>
                        <span className="font-bold text-gray-800">{new Date(notification._creationTime).toLocaleString()}</span>
                      </div>
                      {notification.scheduledFor && (
                        <div className="flex items-center space-x-3">
                          <span className="text-purple-500 text-xl">⏰</span>
                          <span className="text-gray-600 font-semibold">Scheduled:</span>
                          <span className="font-bold text-gray-800">{new Date(notification.scheduledFor).toLocaleString()}</span>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="ml-8">
                    {(notification.status === "pending" || notification.status === "sent") && (
                      <button
                        onClick={() => handleCancel(notification._id)}
                        className="px-6 py-3 bg-gradient-to-r from-red-500 to-pink-500 text-white rounded-2xl font-bold hover:from-red-600 hover:to-pink-600 transition-all duration-300 transform hover:scale-105 shadow-lg font-secondary"
                      >
                        🚫 Cancel
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function NotificationStats() {
  const stats = useQuery(api.notifications.getNotificationStats);

  if (stats === undefined) {
    return (
      <div className="card-modern rounded-3xl shadow-modern p-10">
        <div className="animate-pulse">
          <div className="h-16 bg-gradient-to-r from-gray-200 to-gray-300 rounded-2xl mb-10 animate-shimmer"></div>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-6">
            {[...Array(7)].map((_, i) => (
              <div key={i} className="h-40 bg-gradient-to-r from-gray-200 to-gray-300 rounded-2xl animate-shimmer"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="card-modern rounded-3xl shadow-modern p-10">
        <div className="text-center">
          <div className="w-32 h-32 bg-gradient-to-br from-gray-200 to-gray-300 rounded-full flex items-center justify-center mx-auto mb-8 animate-bounce-in">
            <span className="text-5xl">📊</span>
          </div>
          <p className="text-gray-500 text-xl font-medium">No statistics available yet</p>
        </div>
      </div>
    );
  }

  const statItems = [
    { label: "Total", value: stats.total, gradient: "from-blue-500 to-cyan-500", icon: "📊" },
    { label: "Pending", value: stats.pending, gradient: "from-yellow-500 to-orange-500", icon: "⏳" },
    { label: "Sent", value: stats.sent, gradient: "from-blue-500 to-indigo-500", icon: "📤" },
    { label: "Delivered", value: stats.delivered, gradient: "from-green-500 to-emerald-500", icon: "✅" },
    { label: "Bounced", value: stats.bounced, gradient: "from-red-500 to-pink-500", icon: "❌" },
    { label: "Complained", value: stats.complained, gradient: "from-purple-500 to-indigo-500", icon: "⚠️" },
    { label: "Cancelled", value: stats.cancelled, gradient: "from-gray-500 to-gray-600", icon: "🚫" },
  ];

  const deliveryRate = stats.total > 0 ? ((stats.delivered / (stats.total - stats.pending - stats.cancelled)) * 100 || 0) : 0;

  return (
    <div className="space-y-10">
      <div className="card-modern rounded-3xl shadow-modern overflow-hidden animate-slide-in-up">
        <div className="bg-gradient-to-r from-green-500 via-emerald-600 to-teal-500 p-8 relative overflow-hidden">
          <div className="absolute inset-0 bg-black/10"></div>
          <div className="relative z-10">
            <h2 className="text-4xl font-bold text-white flex items-center font-accent">
              <span className="mr-4 text-5xl animate-float">📊</span>
              Statistics Dashboard
            </h2>
            <p className="text-green-100 mt-3 text-lg font-medium">Monitor your notification performance</p>
          </div>
        </div>
        
        <div className="p-10">
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-8">
            {statItems.map((item, index) => (
              <div 
                key={item.label} 
                className="text-center transform hover:scale-110 transition-all duration-300 animate-slide-in-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className={`bg-gradient-to-br ${item.gradient} text-white rounded-3xl p-8 mb-4 shadow-modern hover:shadow-modern-hover transition-shadow duration-300`}>
                  <div className="text-4xl mb-3">{item.icon}</div>
                  <div className="text-4xl font-bold font-accent">{item.value}</div>
                </div>
                <div className="text-lg font-bold text-gray-700 font-secondary">{item.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {stats.total > 0 && (
        <div className="card-modern rounded-3xl shadow-modern p-10 animate-slide-in-up" style={{ animationDelay: '0.2s' }}>
          <div className="text-center">
            <h3 className="text-3xl font-bold text-gray-900 mb-8 flex items-center justify-center font-accent">
              <span className="mr-4 text-4xl">🎯</span>
              Delivery Performance
            </h3>
            
            <div className="relative inline-flex items-center justify-center w-64 h-64 mb-8">
              <svg className="w-64 h-64 transform -rotate-90" viewBox="0 0 100 100">
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="transparent"
                  className="text-gray-200"
                />
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  stroke="url(#gradient)"
                  strokeWidth="8"
                  fill="transparent"
                  strokeDasharray={`${deliveryRate * 2.51} 251`}
                  strokeLinecap="round"
                  className="transition-all duration-1000 ease-out"
                />
                <defs>
                  <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#10B981" />
                    <stop offset="100%" stopColor="#059669" />
                  </linearGradient>
                </defs>
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-5xl font-bold text-green-600 font-accent">{deliveryRate.toFixed(1)}%</div>
                  <div className="text-lg text-gray-600 font-semibold">Success Rate</div>
                </div>
              </div>
            </div>
            
            <div className="glass-strong rounded-2xl p-8 border border-green-200/50">
              <p className="text-xl text-gray-700 font-medium">
                <span className="font-bold text-green-600 text-2xl">{stats.delivered}</span> delivered out of{" "}
                <span className="font-bold text-gray-800 text-2xl">{stats.total - stats.pending - stats.cancelled}</span> sent
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

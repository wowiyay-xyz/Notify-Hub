/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        'primary': ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        'secondary': ['Poppins', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        'accent': ['Space Grotesk', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      animation: {
        'float': 'float 6s ease-in-out infinite',
        'float-reverse': 'floatReverse 8s ease-in-out infinite',
        'pulse-glow': 'pulse-glow 3s ease-in-out infinite',
        'shimmer': 'shimmer 2s infinite',
        'gradient': 'gradient-shift 4s ease infinite',
        'morphing': 'morphing 8s ease-in-out infinite',
        'slide-in-up': 'slide-in-up 0.6s ease-out',
        'slide-in-left': 'slide-in-left 0.6s ease-out',
        'slide-in-right': 'slide-in-right 0.6s ease-out',
        'bounce-in': 'bounce-in 0.8s ease-out',
      },
      backdropBlur: {
        'strong': '30px',
        'extra': '40px',
      },
      boxShadow: {
        'modern': '0 20px 40px rgba(102, 126, 234, 0.15)',
        'modern-hover': '0 25px 50px rgba(102, 126, 234, 0.25)',
        'glow-modern': '0 0 30px rgba(102, 126, 234, 0.4)',
      },
    },
  },
  plugins: [],
}

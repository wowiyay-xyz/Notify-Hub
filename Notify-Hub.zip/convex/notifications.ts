import { components, internal } from "./_generated/api";
import { Resend, vEmailId, vEmailEvent } from "@convex-dev/resend";
import { query, mutation, internalMutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const resend: Resend = new Resend(components.resend, {
  testMode: false, // Set to true for testing
  onEmailEvent: internal.notifications.handleEmailEvent,
});

// Create a new notification
export const createNotification = mutation({
  args: {
    title: v.string(),
    message: v.string(),
    recipientEmail: v.string(),
    priority: v.union(
      v.literal("low"),
      v.literal("normal"),
      v.literal("high"),
      v.literal("urgent")
    ),
    scheduledFor: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be authenticated to create notifications");
    }

    const notificationId = await ctx.db.insert("notifications", {
      title: args.title,
      message: args.message,
      recipientEmail: args.recipientEmail,
      senderUserId: userId,
      status: "pending",
      priority: args.priority,
      scheduledFor: args.scheduledFor,
    });

    // If not scheduled for later, send immediately
    if (!args.scheduledFor || args.scheduledFor <= Date.now()) {
      await ctx.scheduler.runAfter(0, internal.notifications.sendNotificationEmail, {
        notificationId,
      });
    } else {
      // Schedule for later
      await ctx.scheduler.runAt(args.scheduledFor, internal.notifications.sendNotificationEmail, {
        notificationId,
      });
    }

    return notificationId;
  },
});

// Send notification email (internal)
export const sendNotificationEmail = internalMutation({
  args: {
    notificationId: v.id("notifications"),
  },
  handler: async (ctx, args) => {
    const notification = await ctx.db.get(args.notificationId);
    if (!notification) {
      throw new Error("Notification not found");
    }

    if (notification.status !== "pending") {
      return; // Already processed
    }

    const sender = await ctx.db.get(notification.senderUserId);
    if (!sender) {
      throw new Error("Sender not found");
    }

    const priorityEmoji = {
      low: "📝",
      normal: "📧",
      high: "⚡",
      urgent: "🚨"
    };

    const emailSubject = `${priorityEmoji[notification.priority]} ${notification.title}`;
    const emailBody = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #333; border-bottom: 2px solid #007bff; padding-bottom: 10px;">
          ${priorityEmoji[notification.priority]} ${notification.title}
        </h2>
        <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="font-size: 16px; line-height: 1.6; color: #333; margin: 0;">
            ${notification.message.replace(/\n/g, '<br>')}
          </p>
        </div>
        <div style="border-top: 1px solid #dee2e6; padding-top: 15px; margin-top: 20px;">
          <p style="color: #6c757d; font-size: 14px; margin: 0;">
            Sent by: ${sender.email || sender.name || 'Unknown User'}<br>
            Priority: <span style="text-transform: uppercase; font-weight: bold; color: ${
              notification.priority === 'urgent' ? '#dc3545' :
              notification.priority === 'high' ? '#fd7e14' :
              notification.priority === 'normal' ? '#007bff' : '#6c757d'
            };">${notification.priority}</span><br>
            Sent at: ${new Date().toLocaleString()}
          </p>
        </div>
      </div>
    `;

    try {
      const emailId = await resend.sendEmail(
        ctx,
        `Notifications <notifications@${process.env.RESEND_DOMAIN || 'example.com'}>`,
        notification.recipientEmail,
        emailSubject,
        emailBody
      );

      await ctx.db.patch(args.notificationId, {
        status: "sent",
        emailId: emailId,
      });
    } catch (error) {
      console.error("Failed to send email:", error);
      await ctx.db.patch(args.notificationId, {
        status: "bounced",
      });
    }
  },
});

// Handle email events from Resend webhook
export const handleEmailEvent = internalMutation({
  args: {
    id: vEmailId,
    event: vEmailEvent,
  },
  handler: async (ctx, args) => {
    console.log("Email event received:", args.id, args.event);

    // Log the event
    await ctx.db.insert("emailEvents", {
      emailId: args.id,
      event: args.event.type,
      timestamp: Date.now(),
    });

    // Find the notification with this email ID
    const notification = await ctx.db
      .query("notifications")
      .filter((q) => q.eq(q.field("emailId"), args.id))
      .first();

    if (notification) {
      let newStatus: "pending" | "sent" | "delivered" | "bounced" | "complained" | "cancelled" = notification.status;

      switch (args.event.type) {
        case "email.delivered":
          newStatus = "delivered";
          break;
        case "email.bounced":
          newStatus = "bounced";
          break;
        case "email.complained":
          newStatus = "complained";
          break;
      }

      if (newStatus !== notification.status) {
        await ctx.db.patch(notification._id, { status: newStatus });
      }

      // Update the email event with notification reference
      const emailEvent = await ctx.db
        .query("emailEvents")
        .filter((q) => q.eq(q.field("emailId"), args.id))
        .order("desc")
        .first();

      if (emailEvent) {
        await ctx.db.patch(emailEvent._id, {
          notificationId: notification._id,
        });
      }
    }
  },
});

// Get user's notifications
export const getUserNotifications = query({
  args: {
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const notifications = await ctx.db
      .query("notifications")
      .withIndex("by_sender", (q) => q.eq("senderUserId", userId))
      .order("desc")
      .take(args.limit || 50);

    return notifications;
  },
});

// Get notification statistics
export const getNotificationStats = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }

    const notifications = await ctx.db
      .query("notifications")
      .withIndex("by_sender", (q) => q.eq("senderUserId", userId))
      .collect();

    const stats = {
      total: notifications.length,
      pending: notifications.filter(n => n.status === "pending").length,
      sent: notifications.filter(n => n.status === "sent").length,
      delivered: notifications.filter(n => n.status === "delivered").length,
      bounced: notifications.filter(n => n.status === "bounced").length,
      complained: notifications.filter(n => n.status === "complained").length,
      cancelled: notifications.filter(n => n.status === "cancelled").length,
    };

    return stats;
  },
});

// Cancel a notification
export const cancelNotification = mutation({
  args: {
    notificationId: v.id("notifications"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be authenticated");
    }

    const notification = await ctx.db.get(args.notificationId);
    if (!notification) {
      throw new Error("Notification not found");
    }

    if (notification.senderUserId !== userId) {
      throw new Error("Not authorized to cancel this notification");
    }

    if (notification.status === "pending" || notification.status === "sent") {
      if (notification.emailId) {
        try {
          await resend.cancelEmail(ctx, notification.emailId as any);
        } catch (error) {
          console.log("Could not cancel email (may have already been sent):", error);
        }
      }

      await ctx.db.patch(args.notificationId, {
        status: "cancelled",
      });
    }

    return notification;
  },
});

// Get email events for a notification
export const getEmailEvents = query({
  args: {
    emailId: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const events = await ctx.db
      .query("emailEvents")
      .withIndex("by_email_id", (q) => q.eq("emailId", args.emailId))
      .order("desc")
      .collect();

    return events;
  },
});

import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  notifications: defineTable({
    title: v.string(),
    message: v.string(),
    recipientEmail: v.string(),
    senderUserId: v.id("users"),
    emailId: v.optional(v.string()),
    status: v.union(
      v.literal("pending"),
      v.literal("sent"),
      v.literal("delivered"),
      v.literal("bounced"),
      v.literal("complained"),
      v.literal("cancelled")
    ),
    priority: v.union(
      v.literal("low"),
      v.literal("normal"),
      v.literal("high"),
      v.literal("urgent")
    ),
    scheduledFor: v.optional(v.number()),
  })
    .index("by_sender", ["senderUserId"])
    .index("by_status", ["status"])
    .index("by_scheduled", ["scheduledFor"]),

  emailEvents: defineTable({
    emailId: v.string(),
    event: v.string(),
    timestamp: v.number(),
    notificationId: v.optional(v.id("notifications")),
  }).index("by_email_id", ["emailId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
